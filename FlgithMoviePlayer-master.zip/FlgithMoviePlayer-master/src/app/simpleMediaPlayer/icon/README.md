### UI素材

存放SimpleMediaPlayer的素材图标，使用png格式；
