# Project Demands
## User end features
- [ ] brief interface
- [ ] controll mode: keyboard/button touch
- [ ] support multiple languages
- [ ] movie player

---
## Admin end features
- [ ] interface modify
- [ ] movie source management
---
## Other function
- [ ] Get movie information from WiKi
- [ ] Save&Fetch information from DB